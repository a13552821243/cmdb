
from django.conf.urls import url

from api.views import  asset
from api.views import  asset
urlpatterns = [
    # url(r'^asset',asset.asset),
    url(r'^asset',asset.Asset.as_view()),
    url(r'^test',asset.Test.as_view()),
]
