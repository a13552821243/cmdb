from stark.service.stark import site,StarkConfig,get_choice_text,Option
from api import models
from django.shortcuts import HttpResponse,reverse,redirect,render
from django.utils.safestring import mark_safe

from stark.forms.forms import StarkModelForm

from stark.forms.widgets import DatePickerInput

class ServerModelForm(StarkModelForm):
    class Meta:
        model = models.Server
        fields = "__all__"

        widgets = {
            'latest_date': DatePickerInput(attrs={'class':'date-picker'})
        }





class BusinessUnitConfig(StarkConfig):
    list_display = ['id','name']
site.register(models.BusinessUnit,BusinessUnitConfig)




class IDCUnitConfig(StarkConfig):

    # 展示  以及批量操作
    list_display = [StarkConfig.display_checkbox,'id','name','floor']
    #模糊搜索
    search_list =  ['name','floor']
    ## 排序
    order_by = ['-id']

    # 批量删除
    def multi_delete(self, request):
        pass
        # return redirect('http://www.baidu.com')

    # def abc(self, request):
    #     pass
    multi_delete.text = '批量删除'
    # abc.text = 'aa'
    action_list = [multi_delete]
site.register(models.IDC,IDCUnitConfig)



class ServerUnitConfig(StarkConfig):

    def display_detail(self,row=None,header=False):
        if header:
            return '查看详情'
        return mark_safe('<a href="/stark/api/server/{}/detail/">查看详情</a>'.format(row.pk))


    def display_record(self,row=None,header=False):
        if header:
            return '变更记录'
        return mark_safe('<a href="/stark/api/server/{}/record/">变更记录</a>'.format(row.pk))
    def display_checkbox(self, row=None, header=False):
        if header:
            return '状态'
        '''
        (1, '上架'),
        (2, '在线'),
        (3, '离线'),
        (4, '下架'),
        '''
        color_dict = {1:'green',
                      2:'blue',
                      3:'gray',
                      4:'red'}
        return mark_safe('<span style="color:{}">{}</span>'.format(color_dict[row.device_status_id],row.get_device_status_id_display()))
        # return row.get_device_status_id_display()
    # list_display = ['hostname',display_checkbox,'os_platform','os_version',get_choice_text('device_status_id','2')]
    # list_display = [StarkConfig.display_checkbox,'hostname','os_platform',display_checkbox,'business_unit']
    list_display = [StarkConfig.display_checkbox, 'hostname', 'business_unit','idc', 'os_platform',display_detail,display_record]

    search_list = ['hostname','os_platform','business_unit__name','idc__name']
    list_filter = [
        Option('business_unit',is_choice=False,text_func=lambda x:x.name,value_func=lambda x:x.id,is_multi=True),
        Option('device_status_id',is_choice=True,text_func=lambda x:x[1],value_func=lambda x:x[0])
    ]
    action_list = [StarkConfig.multi_delete]
    model_form_class = ServerModelForm

    def extra_url(self):
        """
        拓展的URL
        :return:
        """
        from django.conf.urls import url
        patterns = [
            url(r'^(\d+)/detail/',self.show_detaile),
            url(r'^(\d+)/record/', self.show_record),

        ]
        return patterns
    def show_detaile(self,request,s_id):
        all_nic = models.NIC.objects.filter(server_id=s_id)
        all_memory = models.Memory.objects.filter(server_id=s_id)
        all_disk = models.Disk.objects.filter(server_id=s_id)
        return render(request,'server_detail.html',{'all_nic':all_nic,'all_memory':all_memory,
                                                    'all_disk':all_disk})
    def show_record(self,request,s_id):
        all_record = models.AssetRecord.objects.filter(server_id=s_id)
        return render(request,'server_record.html',{'all_record':all_record})
site.register(models.Server,ServerUnitConfig)




