from api import models


def process_basic(server,cert_info):
    #        ############### 基础信息 #####################
    print(server)
    print('111111111111111111111111')
    server_info = {}
    server_info.update(cert_info['basic']['data'])
    server_info.update(cert_info['cpu']['data'])
    server_info.update(cert_info['board']['data'])

    models.Server.objects.filter(id=server.id).update(**server_info)



def process_disk(server,cert_info):
    #         ################# 硬盘#############
            # 提交的资产
            disk_info = cert_info['disk']['data']
            print(disk_info)
            #  数据库的资产
            disk_query_info = models.Disk.objects.filter(server=server)
            disk_info_slog_set = set(disk_info)
            disk_query_slot_set = { i.slot for i in disk_query_info}

            dick_add_slot = disk_info_slog_set - disk_query_slot_set    # 1 没有的
            dick_update_slot = disk_info_slog_set & disk_query_slot_set  # 共有的
            dick_del_slot = disk_query_slot_set - disk_info_slog_set    # 2没有的

                # 跟新
            for slot in dick_update_slot:
                row_dict = disk_info[slot]
                obj = models.Disk.objects.filter(slot=slot,server=server).first()
                msg_list = []
                for k,v in row_dict.items():
                    old_value = getattr(obj,k)
                    if v != str(old_value):
                        tp1 = '{}由{}变成{}'.format(models.Disk._meta.get_field(k).verbose_name,old_value,v)
                        msg_list.append(tp1)
                if msg_list:
                    content = '槽位{}的信息发生变化：{}'.format(slot,''.join(msg_list))
                    models.AssetRecord.objects.create(server=server,content=content)
                models.Disk.objects.filter(slot=slot, server=server).update(**disk_info[slot])

                # 删除
            for slot in dick_del_slot:
                models.Disk.objects.filter(slot=slot, server=server).delete()
            if dick_del_slot:
                models.AssetRecord.objects.create(server=server,content='资产变更 槽位{} 的硬盘移除了'.format(''.join(dick_del_slot)))
            # 资产变更  槽位  的硬盘移除了

                # 新增
            for slot in dick_add_slot:
                row_dict = disk_info[slot]

                ' 操作1 新增了一块硬盘  槽位：0 磁盘型号：SAS； 容量：239.36GB'
                msg_list = []
                for k,v in row_dict.items():
                    verbose_name = models.Disk._meta.get_field(k).verbose_name
                    msg_list.append('{}:{}'.format(verbose_name,v))
                # print(row_dict)
                v = disk_info[slot]
                v['server'] = server
                models.Disk.objects.create(**v)
                models.AssetRecord.objects.create(server=server,content='槽位{}上新增了一块硬盘; 信息{}'.format(slot,';'.join(msg_list)))

            # print(models.Disk._meta.get_field('slot').verbose_name)



def process_memory(server,cert_info):
    #### 内存####
    # 提交的资产
    memory_info = cert_info['memory']['data']
    #  数据库的资产
    memory_query_info = models.Memory.objects.filter(server=server)
    memory_info_slog_set = set(memory_info)
    memory_query_slot_set = {i.slot for i in memory_query_info}

    memory_add_slot = memory_info_slog_set - memory_query_slot_set
    memory_update_slot = memory_info_slog_set & memory_query_slot_set
    memory_del_slot = memory_query_slot_set - memory_info_slog_set

    # 跟新
    for slot in memory_update_slot:
        models.Memory.objects.filter(slot=slot, server=server).update(**memory_info[slot])

    # 删除
    for slot in memory_del_slot:
        models.Memory.objects.filter(slot=slot, server=server).delete()
    # 新增
    for slot in memory_add_slot:
        v = memory_info[slot]
        v['server'] = server

        models.Memory.objects.create(**v)



def process_nic(server,cert_info):
    #### 网卡####
    # 提交的资产
    nic_info = cert_info['nic']['data']
    #  数据库的资产
    nic_query_info = models.NIC.objects.filter(server=server)
    nic_info_slog_set = set(nic_info)
    nic_query_slot_set = {i.name for i in nic_query_info}

    nic_add_slot = nic_info_slog_set - nic_query_slot_set
    nic_update_slot = nic_info_slog_set & nic_query_slot_set
    nic_del_slot = nic_query_slot_set - nic_info_slog_set

    # 跟新
    for slot in nic_update_slot:
        models.NIC.objects.filter(name=slot, server=server).update(**nic_info[slot])

    # 删除
    for slot in nic_del_slot:
        models.NIC.objects.filter(name=slot, server=server).delete()
    # 新增
    for slot in nic_add_slot:
        v = nic_info[slot]
        v['server'] = server
        v['name'] = slot
        models.NIC.objects.create(**v)
