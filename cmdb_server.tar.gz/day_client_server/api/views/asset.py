from django.views import View
from django.shortcuts import HttpResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import json
# @csrf_exempt
# def asset(request):
#     if request.method == 'GET':
#         host_list = ['c1.com','c2.com']
#
#         return HttpResponse(json.dumps(host_list))
#     if request.method == 'POST':
#         print(json.loads(request.body))
#         return HttpResponse('接受成功　')
# from django.utils.decorators import method_decorator
# @method_decorator(csrf_exempt,name='dispatch')
# class Asset(View):
#     def get(self,request):
#         host_list = ['c1.com','c2.com']
#
#         return HttpResponse(json.dumps(host_list))
#     def post(self,request):
#         print(json.loads(request.body))
#         return HttpResponse('接受成功　')
import hashlib,time




from rest_framework.views import APIView
from rest_framework.response import Response
from api import models
from api import service

class Asset(APIView):

    def get(self,request):
        host_list = ['c1.com','c2.com']
        return HttpResponse(host_list)

    def post(self,request):
        print(request.data)
        result = {'status':True,'error':None,'data':None}
        cert_info = request.data
        action_type = cert_info.get('type')


        if action_type == 'create':
            #新增服务器
            # 基本信息
            server_info = {}
            server_info.update(cert_info['basic']['data'])
            server_info.update(cert_info['cpu']['data'])
            server_info.update(cert_info['board']['data'])

            server = models.Server.objects.create(**server_info)
            #硬盘
            disk_info = cert_info['disk']['data']
            disk_list = []
            for slot,v in disk_info.items():

                v['server'] = server
                disk_list.append(models.Disk(**v))
            models.Disk.objects.bulk_create(disk_list)
            # 网卡
            nic_info = cert_info['nic']['data']
            nic_list = []
            for name, v in nic_info.items():
                # models.Disk.objects.create(**v)
                v['server'] = server
                v['name'] = name
                nic_list.append(models.NIC(**v))
            models.NIC.objects.bulk_create(nic_list)
            #  内存
            memory_info = cert_info['memory']['data']
            memory_list = []
            for slot, v in memory_info.items():
                # models.Disk.objects.create(**v)
                v['server'] = server
                memory_list.append(models.Memory(**v))
            models.Memory.objects.bulk_create(memory_list)


        elif action_type == 'update':
            # 跟新资产

            hostname = cert_info['basic']['data']['hostname']
            server  = models.Server.objects.filter(hostname=hostname).first()

            service.process_basic(server,cert_info)
            service.process_disk(server, cert_info)
            service.process_memory(server, cert_info)
            service.process_nic(server, cert_info)



        elif action_type == 'host_update':
            # 更新主机  + 跟新资产
            cert = cert_info['cert']
            server = models.Server.objects.filter(hostname=cert).first()
            # 跟新主机名
            server.hostname = cert_info['basic']['data']['hostname']
            server.save()

            service.process_basic(server,cert_info)
            service.process_disk(server, cert_info)
            service.process_memory(server, cert_info)
            service.process_nic(server, cert_info)


        result['data'] = request.data['basic']['data']['hostname']
        return Response(result)

ctime = time.time()
def get_key(ctime):


    key_str = "{}|{}".format(settings.URL_AUTH_KEY,ctime)
    md5 = hashlib.md5()
    md5.update(key_str.encode('utf-8'))

    return md5.hexdigest()

sing_list = {}

class AuthApi(APIView):
    def dispatch(self, request, *args, **kwargs):

        result = {'status':True,'data':'6666'}

        sign = request.GET.get('sign')
        ctime = request.GET.get('ctime',1)
        server_time = int(time.time())*1000

        if server_time - int(ctime) > 5000:
            result['status'] = False
            result['data'] = '证书已经过期'
            return HttpResponse(json.dumps(result))

        if sign in sing_list:
            result['status'] = False
            result['data'] = '证书已使用'
            return HttpResponse(json.dumps(result))
        if sign != get_key(ctime):
            result['status'] = False
            result['data'] = '校验不成功'
            return HttpResponse(json.dumps(result))

        sing_list[sign] = ctime

        if result['status']:
            return super().dispatch(request, *args, **kwargs)
        else:
            return HttpResponse(json.dumps(result))


from utils.security import decrypt
class Asset(AuthApi):

    def get(self,request):
        host_list = ['c1.com','c2.com']
        return HttpResponse(host_list)

    def post(self,request):
        # print(request.data)
        cert_info = json.loads(decrypt(request.body).decode('utf-8'))
        # print(cert_info)
        result = {'status':True,'error':None,'data':None}
        # cert_info = request.data
        action_type = cert_info.get('type')
        print(action_type)
        print('zzzzzzzzzzz')


        if action_type == 'create':
            #新增服务器
            # 基本信息
            server_info = {}
            server_info.update(cert_info['basic']['data'])
            server_info.update(cert_info['cpu']['data'])
            server_info.update(cert_info['board']['data'])

            server = models.Server.objects.create(**server_info)
            #硬盘
            disk_info = cert_info['disk']['data']
            disk_list = []
            for slot,v in disk_info.items():

                v['server'] = server
                disk_list.append(models.Disk(**v))
            models.Disk.objects.bulk_create(disk_list)
            # 网卡
            nic_info = cert_info['nic']['data']
            nic_list = []
            for name, v in nic_info.items():
                # models.Disk.objects.create(**v)
                v['server'] = server
                v['name'] = name
                nic_list.append(models.NIC(**v))
            models.NIC.objects.bulk_create(nic_list)
            #  内存
            memory_info = cert_info['memory']['data']
            memory_list = []
            for slot, v in memory_info.items():
                # models.Disk.objects.create(**v)
                v['server'] = server
                memory_list.append(models.Memory(**v))
            models.Memory.objects.bulk_create(memory_list)


        elif action_type == 'update':
            # 跟新资产

            hostname = cert_info['basic']['data']['hostname']
            print(hostname)
            server  = models.Server.objects.filter(hostname=hostname).first()
            print(server)
            print('111111111111111111')

            service.process_basic(server,cert_info)
            service.process_disk(server, cert_info)
            service.process_memory(server, cert_info)
            service.process_nic(server, cert_info)



        elif action_type == 'host_update':
            # 更新主机  + 跟新资产
            cert = cert_info['cert']
            server = models.Server.objects.filter(hostname=cert).first()
            # 跟新主机名

            if not server:
                result['error'] = '主机名不存在'
                result['status'] = False

            else:
                server.hostname = cert_info['basic']['data']['hostname']
                server.save()

                service.process_basic(server,cert_info)
                service.process_disk(server, cert_info)
                service.process_memory(server, cert_info)
                service.process_nic(server, cert_info)


        result['data'] = cert_info['basic']['data']['hostname']
        return Response(result)

class Test(AuthApi):
    def get(self):
        pass
    def post(self,request):
        return Response({'xxx':111})
