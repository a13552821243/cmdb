import sys,os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/confing')
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/lib')
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/src/engine')
import settings
from module_srting import import_sting
from agent import AgentHandler
def run():
   engine_path = settings.ENGINE_HANDLER.get(settings.ENGINE)
   obj = import_sting(engine_path)()
   obj.handler()
