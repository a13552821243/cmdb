# -*- coding: utf-8 -*-
import settings
from module_srting import import_sting

def get_server_info(handler,hostname=None):
    """
    获取所有资产，并返回
    :return:
    """
    info = {}
    for name,path in settings.PLUGINS_DICT.items():
        cls = import_sting(path)()
        #  获取内存， 网卡的类
        info[name] = cls.process(handler,hostname)
    # print(info)
    return info
