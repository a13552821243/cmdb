import sys
# sys.platform
from confing import settings
class BasePlugin:

    def __init__(self):
        self.debug = settings.DEBUG
        self.base_dir = settings.BASE_DIR

    def win(self):
        raise NotImplementedError('win mult ')
    def linux(self):
        raise NotImplementedError('win mult ')


    def get_os(self,handler,hostname):
        # os = handler.cmd('查询OS系统',hostname)
        return 'linux'

    def process(self,handler,hostname):
        os = self.get_os(handler,hostname)
        if os == 'windows':

            return self.win(handler,hostname)
        else:

            return self.linux(handler,hostname)