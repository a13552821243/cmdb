# -*- coding: utf-8 -*-
import os,sys
#sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import settings
from plugins import get_server_info
import requests,json
class BaseHandler(object):
    def handler(self):
        raise NotImplementedError('handler mult Implemented')

    def cmd(self):
        raise NotImplementedError('cmd mult Implemented')


class SshandSaltHandler(BaseHandler):

    def handler(self):
        """
        salt 模式处理资产采集
        :return:
        """
        # print('salt模式')
        #1 获取未采集的主机列表
        r1 = requests.get(url='http://127.0.0.1:8000/api/asset/')
        # print(r1)
        host_list = r1.json()
        print(host_list)
        from concurrent.futures import ThreadPoolExecutor
        pool = ThreadPoolExecutor(10)
        for hostname in host_list:

            pool.submit(self.task,hostname)



    def task(self,hostname):
        # 采集资材并且汇报
        info = get_server_info(self,hostname)
        # 采集到的自残 并上传到api,接受api返回的数据
        r1 = requests.post(
            url="http://127.0.0.1:8000/api/asset/",
            data=json.dumps(info),
            headers={'Content-Type': 'application/json'},

        )
        print(r1)
        print(r1.text)
