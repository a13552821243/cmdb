# -*- coding: utf-8 -*-

import os,sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from base import BaseHandler
import subprocess,json,requests,os
from plugins import get_server_info
import settings

from auth import get_key
import time
class AgentHandler(BaseHandler):

    def cmd(self,command,hostname=None):
        return subprocess.getoutput(command)

    def handler(self):
        """
        agent 模式处理资产采集
        :return:
        """
        print('agent模式')
        info= get_server_info(self)
        #info['disk']['data'].pop('1')

        # 唯一标识
        if not os.path.exists(settings.CERT_FILE_PATH):
            # 新增
            info['type'] = 'create'
        else:
            with open(settings.CERT_FILE_PATH,'r',encoding='utf-8') as f:
                cert = f.read()
                hostname = info['basic']['data']['hostname']
            if cert == hostname:
                # 跟新资产信息
                info['type'] = 'update'
            else:
                # 更改主机名  跟新资产信息
                info['type'] = 'host_update'
                info['cert'] = cert




        # 3 # 上报到API
        ctime = int(time.time()*1000)
        from lib.security import encrypt
        r1 = requests.post(
            url = "http://10.240.17.103:8888/api/asset/",
            data = encrypt(json.dumps(info).encode('utf-8')),
            headers = {'Content-Type':'application/json'},
            params = {'sign': get_key(ctime), 'ctime': ctime},

        )
        print(r1)
        # print(r1.json())

        # 4 跟新唯一标示

        response= json.loads(r1.text)

        if response.get('status'):
            with open(settings.CERT_FILE_PATH,'w',encoding='utf-8') as f:
                f.write(response['data'])

        print(response)

