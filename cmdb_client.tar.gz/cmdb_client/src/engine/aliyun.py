from src.engine.base import BaseHandler

class AliyunHandler(BaseHandler):

    def handler(self):
        """
        salt 模式处理资产采集
        :return:
        """
        print('aliyun模式')

        # 调用plugins下的文件