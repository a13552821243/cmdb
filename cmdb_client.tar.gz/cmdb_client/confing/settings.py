#-*- coding:utf-8 -*-
import os,sys
ENGINE = 'agent'

ENGINE_HANDLER = {
    'agent': 'src.engine.agent.AgentHandler',
    'salt':'src.engine.salt.SaltHandler',
    'ssh' : 'src.engine.ssh.SshHandler',
    'aliyun' : 'src.engine.aliyun.AliyunHandler',
}

PLUGINS_DICT ={
    'disk' : 'src.plugins.disk.Disk',
    'memory' : 'src.plugins.memory.Memory',
    'nic' : 'src.plugins.network.Network',
    'cpu' : 'src.plugins.cpu.Cpu',
    'basic' : 'src.plugins.basic.Basic',
    'board' : 'src.plugins.main_board.MainBoard',
}
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# SSH模式key
SSH_PRIVATE_KEY = '私钥'
SSH_PORT = '22'
SSH_USER = 'cmdb'

DEBUG = False
#DEBUG = True

# 日志文件的地址
LOG_FILE_PATH = os.path.join(BASE_DIR,'log','cmdb.log')


# cert 文件的地址
CERT_FILE_PATH = os.path.join(BASE_DIR,'confing','cert')


URL_AUTH_KEY = 'abcdefg'



PUB_KEY = b'LS0tLS1CRUdJTiBSU0EgUFVCTElDIEtFWS0tLS0tCk1JR0pBb0dCQU41bWJjSXFHaXVrcjM3cCtzRTR4WCtJWWhQZ0g2T29Ob3ZFTS9OT0VpSHhJaFZuZEE0bnZTcGoKZmpVU2w1UVpLektzeWlzbjBoZm0wNURwRmZCTS8rMDB1b2EvY2pvcGF6RzB4NFAxb2tIdXg0ZDN5eGpTc3p2WAo5QzFVMGNoODE3R0lsM3Q1TFloWXhGNk1mNEVGT2RUK2VzYy9kZHhjODVNQU16Z29ySTR0QWdNQkFBRT0KLS0tLS1FTkQgUlNBIFBVQkxJQyBLRVktLS0tLQo='


