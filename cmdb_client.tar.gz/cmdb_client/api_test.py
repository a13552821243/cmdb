import requests
import hashlib,time
key = 'sdfsd'

ctime = int(time.time() * 1000)

def get_key(ctime):


    key_str = "{}|{}".format(key,ctime)
    md5 = hashlib.md5()
    md5.update(key_str.encode('utf-8'))

    return md5.hexdigest()



r1 = requests.post(
    url='http://127.0.0.1:8000/api/test/',
    params = {'sign':get_key(ctime),'ctime':ctime},
)

print(r1.json())
print(r1.url,r1.json())