# -*- coding: utf-8 -*-
import settings
import hashlib
def get_key(ctime):


    key_str = "{}|{}".format(settings.URL_AUTH_KEY,ctime)
    md5 = hashlib.md5()
    md5.update(key_str.encode('utf-8'))

    return md5.hexdigest()
