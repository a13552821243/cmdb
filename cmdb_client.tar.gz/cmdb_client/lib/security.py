import base64,rsa
from confing import settings

def encrypt(value):
    key_str = base64.standard_b64decode(settings.PUB_KEY)
    pk = rsa.PublicKey.load_pkcs1(key_str)

    msg_list = []
    for i in range(0,len(value),117):
        chunk = value[i:i+117]
        val = rsa.encrypt(chunk,pk)
        msg_list.append(val)
    # val = rsa.encrypt(value.encode('utf-8'),pk)
    return b''.join(msg_list)