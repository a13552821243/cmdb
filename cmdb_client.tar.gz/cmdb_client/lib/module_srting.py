# -*- coding: utf-8 -*-
import importlib

def import_sting(path):
    module_path, engine_class = path.rsplit('.', maxsplit=1)
    module = importlib.import_module(module_path)
    return getattr(module, engine_class)

