import requests
import json
# import traceback
# from concurrent.futures import ThreadPoolExecutor
# import subprocess
#
# def agent():
#
#     # 1 执行命令采集资产信息：硬盘，内存，网卡
#
#     # 2 错误信息处理   日志 traceback.format_exc()
#
#
#
#     # 3. 自动发现
#
#     '''
#     唯一标示
#
#     物理机 s/n号
#     物理机 + 虚拟机：
#         1. 物理机 虚拟机 分开管理
#         2. 主机名 + 文件
#            规则：
#                1. 新的机子 以主机名的一个空的文件 采集信息存储到文件中 当前是新增
#                2. 老的机子  改主机名  文件内容跟新 当前便跟 文件名也跟新
#
#     '''
#
#
#
a = {'aaa': 111}
r1  = requests.post(
    url = "http://10.240.17.103:8888/api/test/",
    data =json.dumps(a)
    )
print(r1.text)
#
#
#
# def ssh():
#     r1 = requests.get(url='http://127.0.0.1:8000/api/asset/')
#     host_list = r1.json()
#     poll = ThreadPoolExecutor(10)
#     for i in host_list:
#         poll.submit(agent(),host_list)
#
# ssh()


# import requests
# import hashlib,time
# key = 'sdfsd'
#
# ctime = time.time()
#
# def get_key(ctime):
#
#
#     key_str = "{}|{}".format(key,ctime)
#     md5 = hashlib.md5()
#     md5.update(key_str.encode('utf-8'))
#
#     return md5.hexdigest()
#
#
#
# r1 = requests.post(
#     url='http://127.0.0.1:8000/api/test/?sign=1eaee3b5394915ddf26c2f249e2acf54&ctime=1551334671803',
#     # params = {'sign':get_key(ctime),'ctime':ctime},
# )
#
# print(r1.json())
# print(r1.url,r1.json())


import os

for i in range(0,10):
    for x in range(1,10):
        print(i*x)








